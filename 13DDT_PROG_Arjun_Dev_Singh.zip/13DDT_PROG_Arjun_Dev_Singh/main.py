import tkinter as tk
from PIL import Image, ImageTk
from tkintermapview import TkinterMapView

def show_directions():
    start = your_location.get()
    end = destination.get()
    if not start or not end:
        return
    # Clear previous markers and paths
    map_widget.set_address(start, marker=True)
    map_widget.set_address(end, marker=True)
    coords1 = map_widget.geocode(start)
    coords2 = map_widget.geocode(end)
    if coords1 and coords2:
        map_widget.set_path([coords1, coords2])
        # Center map between the two points
        lat_center = (coords1[0] + coords2[0]) / 2
        lon_center = (coords1[1] + coords2[1]) / 2
        map_widget.set_position(lat_center, lon_center)
        map_widget.set_zoom(14)

# Create the main window
root = tk.Tk()
root.title("Macleans Navigator")
root.geometry("800x600")
root.iconbitmap("images/logo.ico")
root.configure(bg="blue")

# Set background image
bg_image = Image.open("images/bg2.jpg")
bg_image = bg_image.resize((800, 600))
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)
bg_label.image = bg_photo

# Header
header = tk.Label(root, text="Macleans Navigator", bg="white", font=("Arial", 16, "bold"), width=80, pady=10)
header.pack(pady=10)

# Frame for location and destination
input_frame = tk.Frame(root, bg="blue")
input_frame.pack(pady=10)

# location input
your_location = tk.Entry(input_frame, width=30)
your_location.grid(row=0, column=0, padx=5)
your_location_btn = tk.Button(input_frame, text="Enter", command=show_directions)
your_location_btn.grid(row=0, column=1, padx=5)

# Destination input
destination = tk.Entry(input_frame, width=30)
destination.grid(row=0, column=2, padx=5)
destination_btn = tk.Button(input_frame, text="Enter", command=show_directions)
destination_btn.grid(row=0, column=3, padx=5)

# Map area using TkinterMapView
map_widget = TkinterMapView(root, width=780, height=400, corner_radius=0)
map_widget.set_position(-36.8861, 174.9047)  # Default: Macleans College
map_widget.set_zoom(15)
map_widget.pack(pady=15, expand=True, fill="both")

# Footer with credits and contact
footer_frame = tk.Frame(root, bg="blue")
footer_frame.pack(pady=20)

credits_btn = tk.Button(footer_frame, text="Credits", width=20)
credits_btn.grid(row=0, column=0, padx=10)

contact_btn = tk.Button(footer_frame, text="Contact Us", width=20)
contact_btn.grid(row=0, column=1, padx=10)

# Start the GUI loop
root.mainloop()
