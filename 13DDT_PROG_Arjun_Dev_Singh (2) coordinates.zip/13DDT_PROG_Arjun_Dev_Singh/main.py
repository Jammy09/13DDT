import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk, ImageDraw

# Hardcoded building coordinates (x, y) on the static image
BUILDINGS = {
    "Batten": (1065, 910),
    "Kupe": (840, 185),
    "Rutherford": (930, 360),
    "Te Kanawa": (400, 215),
    "Upham": (185, 625),
    "Mansfield": (1060, 460),
    "Snell": (300, 540),
    "Hillary": (615, 450),
}

# Load the map image
MAP_PATH = "images/map.jpg"
MAP_WIDTH = 1280
MAP_HEIGHT = 960

class MapApp:
    def __init__(self, root):
        self.root = root
        self.root.title("School Navigator")
        self.root.geometry(f"{MAP_WIDTH+200}x{MAP_HEIGHT+50}")

        # Load image
        self.original_image = Image.open(MAP_PATH).resize((MAP_WIDTH, MAP_HEIGHT))
        self.display_image = self.original_image.copy()
        self.tk_image = ImageTk.PhotoImage(self.display_image)

        self.canvas = tk.Canvas(root, width=MAP_WIDTH, height=MAP_HEIGHT)
        self.canvas.grid(row=0, column=0, rowspan=6)

        self.image_on_canvas = self.canvas.create_image(0, 0, anchor="nw", image=self.tk_image)

        # Dropdowns
        self.start_var = tk.StringVar()
        self.end_var = tk.StringVar()

        ttk.Label(root, text="Start:").grid(row=0, column=1, sticky="w")
        self.start_menu = ttk.Combobox(root, textvariable=self.start_var, values=list(BUILDINGS.keys()))
        self.start_menu.grid(row=1, column=1)

        ttk.Label(root, text="Destination:").grid(row=2, column=1, sticky="w")
        self.end_menu = ttk.Combobox(root, textvariable=self.end_var, values=list(BUILDINGS.keys()))
        self.end_menu.grid(row=3, column=1)

        self.route_btn = ttk.Button(root, text="Show Route", command=self.draw_route)
        self.route_btn.grid(row=4, column=1, pady=10)

        self.clear_btn = ttk.Button(root, text="Clear", command=self.clear_route)
        self.clear_btn.grid(row=5, column=1)

    def draw_route(self):
        start = self.start_var.get()
        end = self.end_var.get()

        if start not in BUILDINGS or end not in BUILDINGS:
            print("Invalid selection.")
            return

        img = self.original_image.copy()
        draw = ImageDraw.Draw(img)
        start_xy = BUILDINGS[start]
        end_xy = BUILDINGS[end]

        # Draw path
        draw.line([start_xy, end_xy], fill="red", width=4)

        # Draw circles
        r = 6
        draw.ellipse([start_xy[0]-r, start_xy[1]-r, start_xy[0]+r, start_xy[1]+r], fill="green")
        draw.ellipse([end_xy[0]-r, end_xy[1]-r, end_xy[0]+r, end_xy[1]+r], fill="blue")

        self.tk_image = ImageTk.PhotoImage(img)
        self.canvas.itemconfig(self.image_on_canvas, image=self.tk_image)

    def clear_route(self):
        self.tk_image = ImageTk.PhotoImage(self.original_image)
        self.canvas.itemconfig(self.image_on_canvas, image=self.tk_image)

if __name__ == "__main__":
    root = tk.Tk()
    app = MapApp(root)
    root.mainloop()
