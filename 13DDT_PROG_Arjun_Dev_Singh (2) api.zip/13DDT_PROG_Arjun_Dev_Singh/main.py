import tkinter as tk
from PIL import Image, ImageTk
from tkintermapview import TkinterMapView

def show_route():
    start = your_location.get().strip()
    end = destination.get().strip()

    if not start or not end:
        print("Missing input.")
        return

    # Remove previous markers and paths
    map_widget.delete_all_marker()
    map_widget.delete_all_path()

    # Set markers for start and end
    start_coords = map_widget.set_address(start, marker=True)
    end_coords = map_widget.set_address(end, marker=True)

    # Draw a path if both locations are valid
    if start_coords and end_coords:
        map_widget.set_path([start_coords, end_coords])
        # Center the map between the two points
        lat_center = (start_coords[0] + end_coords[0]) / 2
        lon_center = (start_coords[1] + end_coords[1]) / 2
        map_widget.set_position(lat_center, lon_center)
        map_widget.set_zoom(14)

# Main GUI setup
root = tk.Tk()
root.title("Macleans Navigator")
root.geometry("800x600")
root.iconbitmap("images/logo.ico")
root.configure(bg="blue")

# Background image
bg_image = Image.open("images/bg2.jpg").resize((800, 600))
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Header
header = tk.Label(root, text="Macleans Navigator", bg="white",
                  font=("Arial", 16, "bold"), width=80, pady=10)
header.pack(pady=10)

# Input section
input_frame = tk.Frame(root, bg="blue")
input_frame.pack(pady=10)

your_location = tk.Entry(input_frame, width=30)
your_location.grid(row=0, column=0, padx=5)
your_location_btn = tk.Button(input_frame, text="Enter", command=show_route)
your_location_btn.grid(row=0, column=1, padx=5)

destination = tk.Entry(input_frame, width=30)
destination.grid(row=0, column=2, padx=5)
destination_btn = tk.Button(input_frame, text="Enter", command=show_route)
destination_btn.grid(row=0, column=3, padx=5)

# Use TkinterMapView to display the map
map_widget = TkinterMapView(root, width=780, height=400, corner_radius=0)
map_widget.set_position(-36.8861, 174.9047)
map_widget.set_zoom(15)
map_widget.pack(pady=15, expand=True, fill="both")

# Footer
footer_frame = tk.Frame(root, bg="blue")
footer_frame.pack(pady=20)

credits_btn = tk.Button(footer_frame, text="Credits", width=20)
credits_btn.grid(row=0, column=0, padx=10)

contact_btn = tk.Button(footer_frame, text="Contact Us", width=20)
contact_btn.grid(row=0, column=1, padx=10)

# Start the app
root.mainloop()
